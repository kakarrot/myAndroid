/** Automatically generated file. DO NOT MODIFY */
package csh.cryptonite;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}