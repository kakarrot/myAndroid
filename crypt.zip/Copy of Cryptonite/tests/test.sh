#! /bin/bash

ant clean debug
ant uninstall
ant installt
ant test
