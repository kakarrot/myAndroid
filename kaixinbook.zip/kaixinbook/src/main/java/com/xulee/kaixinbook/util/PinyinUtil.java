package com.xulee.kaixinbook.util;


import com.github.promeg.pinyinhelper.Pinyin;

/**
 * 拼音工具类
 *
 * @author yuanhang
 *
 */
public class PinyinUtil {
	/**
	 * 将字符串中的中文转化为拼音,其他字符不变
	 *
	 * @param inputString
	 * @return
	 */
	public static String getPingYin(String inputString) {

		char[] input = inputString.trim().toCharArray();
		String output = "";

		for (int i = 0; i < input.length; i++) {
			if (java.lang.Character.toString(input[i]).matches("[\\u4E00-\\u9FA5]+")) {
				String temp = Pinyin.toPinyin(input[i]);
				output += temp;
			} else
				output += java.lang.Character.toString(input[i]);
		}
		return output;
	}
}
