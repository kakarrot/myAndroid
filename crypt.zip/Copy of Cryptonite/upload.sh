#! /bin/bash

./googlecode_upload.py --summary="Cryptonite Android Package" --project=cryptonite --user=christoph.schmidthieber --labels=Featured,Type-Package ${1}
