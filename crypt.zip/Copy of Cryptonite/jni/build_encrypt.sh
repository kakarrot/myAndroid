g++ android_key.cpp -DSTANDALONE -lcrypto -o encrypt
