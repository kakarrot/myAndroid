#! /bin/bash

adb uninstall csh.cryptonite
adb install bin/cryptonite-debug.apk
